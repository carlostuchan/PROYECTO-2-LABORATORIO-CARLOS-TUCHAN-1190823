﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO_2_PROGRAMACION
{
    internal class Program
    { 
        static void Main()
        {
            Console.WriteLine("Bienvenido al juego de dados, ¿Cuántas partidas desea jugar?");
            int partidas = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("¿Cuántos tiros desea por cada partida?");
            int tiros = Convert.ToInt32(Console.ReadLine());

            int puntosjuga = 0;
            int puntoscasa = 0;
            int tiroganadojugador = 0;
            int tiropar = 0;
            int tiroimpar = 0;
            int tiroigual = 0;

            Random random = new Random();

            for (int partida = 1; partida <= partidas; partida++)
            {
                Console.WriteLine($"Partida no. {partida}:");
                int puntospartida = 0;
                bool ganajugador = partidacompleta(random, tiros, ref puntospartida, ref tiropar, ref tiroimpar, ref tiroigual);

                if (ganajugador)
                {
                    tiroganadojugador++;
                    puntosjuga += puntospartida;
                    Console.WriteLine("¡Felicidades! ¡Ganaste!");
                }
                else
                {
                    puntoscasa += puntospartida;
                    Console.WriteLine("¡A la próxima será! :( ganó la Casa.");
                }

                Console.WriteLine();
            }

            resultadosfinales(puntosjuga, puntoscasa, tiroganadojugador, partidas, tiropar, tiroimpar, tiroigual);
        }

        static bool partidacompleta(Random random, int cantitiros, ref int puntospartida, ref int tiropar, ref int tiroimpar, ref int tiroigual)
        {
            bool ganajugador = false;

            for (int tiro = 1; tiro <= cantitiros; tiro++)
            {
                int dado1 = random.Next(1, 7);
                int dado2 = random.Next(1, 7);
                int sumadados = dado1 + dado2;

                Console.WriteLine($"Tiro {tiro}: Dado 1: {dado1}, Dado 2: {dado2}, Suma: {sumadados}");

                if (tiro == 1)
                {
                    if (sumadados == 12 || sumadados == 6)
                    {
                        puntospartida = 12;
                        ganajugador = true;
                        break;
                    }
                    else if (sumadados == 4 || sumadados == 6 || sumadados == 10)
                    {
                        puntospartida = 12;
                        break;
                    }
                    else if (sumadados == 11)
                    {
                        puntospartida = 6;
                        break;
                    }
                    else
                    {
                        puntospartida = sumadados;
                    }
                }
                else
                {
                    if (sumadados == puntospartida)
                    {
                        ganajugador = true;
                        break;
                    }
                    else if (sumadados == 11)
                    {
                        puntospartida = 6;
                        break;
                    }
                }

                if (sumadados % 2 == 0)
                {
                    tiropar++;
                }
                else
                {
                    tiroimpar++;
                }

                if (dado1 == dado2)
                {
                    tiroigual++;
                }
            }

            return ganajugador;
        }

        static void resultadosfinales(int puntosjugador, int puntoscasa, int tiroganadojug, int partidas, int tiropar, int tiroimpar, int tiroigual)
        {
            Console.WriteLine("Estos son los resultados finales, ¡Grácias por jugar!");
            Console.WriteLine($"Puntaje final (jugador): {puntosjugador}");
            Console.WriteLine($"Puntaje final (Casa): {puntoscasa}");
            Console.WriteLine($"Tiros ganados por el jugador: {tiroganadojug}");
            Console.WriteLine($"Probabilidad de ganar: {((double)tiroganadojug / partidas) * 100}%");
            Console.WriteLine($"Tiros con números pares: {tiropar}");
            Console.WriteLine($"Tiros con números impares: {tiroimpar}");
            Console.WriteLine($"Tiros con números iguales: {tiroigual}");
            Console.WriteLine("¡Esperamos vuelva a jugar pronto!, para reiniciar el juego compile de nuevo.");
        }
    }

}



    







    

